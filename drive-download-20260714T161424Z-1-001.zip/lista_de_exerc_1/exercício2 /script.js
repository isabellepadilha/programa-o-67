let valorPago = parseFloat (prompt("Informe o valor pago,por favor."));
let valorDoProduto = parseFloat (prompt("Informe o valor do produto, por favor."));
let resultado = ((valorPago)- (valorDoProduto));
alert("Seu troco será de " + (resultado));
