let precoQuilo = prompt("Informe o valor do quilo de acordo com o valor do estabelecimento,por favor.");
let quilosConsumidos = prompt("Informe quantos quilos foram consumidos,por favor.");
let valorAPagar = ((precoQuilo) * (quilosConsumidos));
alert("O valor a pagar foi de " + (valorAPagar));
