let valorDolares = parseFloat(prompt("Informe a quantidade de doláres guardados no cofre."));
let cotacaoDolar = parseFloat(prompt("Informe a cotação do dolar nesse dia."));
let totalValor = ((valorDolares)* (cotacaoDolar));
alert("O valor total do seu dinheiro é " + (totalValor.toFixed(2)));
alert("Obrigada seu pobre #amopobre.");

