let porcentagemDesconto = 5;
let precoProduto = parseFloat (prompt ("Infome o valor pago."));
let resultadoDoProduto = (((porcentagemDesconto)*(precoProduto))/100);

alert ("O valor do seu desconto foi de " + (resultadoDoProduto) + " reais");