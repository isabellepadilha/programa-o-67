let quilo = prompt("Informe o kg da sua refeição.");
const precoQuilo = 28.00;
let resultado = ((quilo)*(precoQuilo));
console.log((quilo)*precoQuilo);
alert("Sua refeição custou "  +  (resultado));
alert ("Obrigada, Volte Sempre!");
// prompt dá a função de adcionar a valor na página
//
