let pesoOriginal = parseFloat (prompt("Informe o seu peso atual."));
let pesoCasoEngorde = 15/100;
let pesoComAumento = ((pesoOriginal) + (pesoCasoEngorde));
let pesoDoEmagrecimento = 20/100
let pesoComAumento2 = ((pesoOriginal)- (pesoDoEmagrecimento));

alert("O seu peso com aumento de 15% é " + (pesoComAumento.toFixed(2)));
alert("Seu peso com redução de 20% é " + (pesoComAumento2.toFixed(2)));