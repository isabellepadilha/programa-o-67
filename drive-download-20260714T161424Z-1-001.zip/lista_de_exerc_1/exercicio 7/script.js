let p1 = 2;
let p2 = 3;
let p3 = 5;

let nota1 = parseFloat (prompt("Informe sua primeira nota."));
let nota2 = parseFloat (prompt("Informe sua segunda nota."));
let nota3 = parseFloat (prompt("Informe sua terceira nota."));

let valorMedia = (((nota1)*(p1) + (nota2)*(p2) + (nota3)*(p3))/10);

alert("Sua média é igual " + (valorMedia.toFixed(2)));
alert("Estude mais ser humano");

