let precoOriginal = parseFloat (prompt("Informe o preço original do produto por favor."));
let precoCobrado = parseFloat (prompt("Informe o preço cobrado após o desconto por favor."));
let resultadoFinal = ((((precoOriginal)- (precoCobrado))/precoOriginal)*100);

alert ("Seu desconto foi de " + (resultadoFinal.toFixed(2)) + "%");