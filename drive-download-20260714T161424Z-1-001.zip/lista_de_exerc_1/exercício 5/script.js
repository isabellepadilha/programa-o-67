const valorPedreiro = 20.00;
const valorPintor = 16.00;
let precoPedreiro = parseFloat (prompt("Informe as horas trabalhadas do pedreiro."));
let precoPintor = parseFloat (prompt("Informe as horas trabalhadas do pintor.")) ;
let totalPedreiro = parseFloat ((valorPedreiro)* (precoPedreiro));
let totalPintor = parseFloat ((valorPintor)*(precoPintor));
let totalObra = parseFloat ((totalPedreiro)  +  (totalPintor))
alert("O valor total do pedreiro será de "  +  (totalPedreiro.toFixed(2)));
alert("O valor total do pedreiro será de "  +  (totalPintor.toFixed(2)));
alert("O valor total da obra será de "  +  (totalObra.toFixed(2)));
//to.fixed significa quantas casas decimais poderam aparecer
//
// parseFloat serve para adicionar numeros decimais
//

