let baseTerreno = parseFloat(prompt("Informe a base do seu terreno em metros."));
let alturaTerreno = parseFloat(prompt("Informe a altura do seu terreno em metros."));
let precoMetro = parseFloat(prompt("Informe o preço por metro quadrado cobrado."));

let areaTerreno= (((baseTerreno)*(alturaTerreno)/2));
let valorEstimado = ((precoMetro)*(areaTerreno));

alert("O tamanho da área do seu terreno é de " + (areaTerreno));
alert("O preço estimado do seu terreno foi de " + (valorEstimado));