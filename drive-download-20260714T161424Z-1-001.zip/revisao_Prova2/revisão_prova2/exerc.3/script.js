let numeroDias = parseFloat(prompt("Informe o número de dias usado por mês."));
let horasUso = parseFloat(prompt("Informe o número de horas de uso por dia."));
let consumoEquipamento = parseFloat(prompt("Informe o consumo de energia do equipamento KWh.."));
let custoKWh= parseFloat(prompt("Informe o valor cobrado por KWh."));
let taxaFixa= parseFloat(prompt("Informe o valor da taxa fixa de manutenção"));

let totalHoras= ((numeroDias)*(horasUso));
let consumoTotal = ((totalHoras)*(consumoEquipamento));
let custoEnergia = ((consumoTotal)*(custoKWh));
let custoTotal = ((custoEnergia)+ (taxaFixa));

alert("O custo total foi de " + (custoTotal));