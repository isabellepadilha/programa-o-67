let volumeLitros = parseFloat(prompt("Informe o volume inicial em litros, por favor."));
let litrosHora = parseFloat(prompt("Informe os litros adicionados por hora, por favor"));
let tempoAbastecimento = parseFloat(prompt("Informe o tempo de abastecimento em horas"));
let resultado = (((litrosHora)* (tempoAbastecimento))+volumeLitros);

alert("O volume total do reservatório é de " + (resultado.toFixed(2)));