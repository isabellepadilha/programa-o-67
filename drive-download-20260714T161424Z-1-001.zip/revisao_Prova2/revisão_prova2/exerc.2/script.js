let numeroPaginas= parseFloat(prompt("Informe o número de páginas do material"));
let quatidadeCopias= parseFloat(prompt("Informe o número de cópias"));
let custoPagina= parseFloat(prompt("Informe o valor cobrado por cada página."));
let percTaxa= parseFloat(prompt("Informe a porcentagem da taxa cobrada no estabelecimento"));
 
let totalPagina= ((numeroPaginas)+(quantidadeCopias));
let custoBase= ((custoPagina)*(totalPagina) );
let valorTaxa= (((percTaxa)*(custoBase))/100);
let valorTotal= ((custoBase)+(valorTaxa));

alert("O total de páginas foi de " + (totalPagina));
alert("O custo Base foi de " + (custoBase));
alert("O valor da taxa foi de " + (valorTaxa));
alert("O valo total foi de " + (valorTotal));