let numeroDisciplinas = parseInt(prompt("Informe o número de disciplinas, por favor"));
let horaDiciplina = parseFloat(prompt("Informe a quantidade das horas de estudo por disciplina"));
let diasEstudo = parseFloat(prompt("Informe a quantidade de dias de estudo"));

let totalHoras = (numeroDisciplinas)*(horaDiciplina);
let totalPeriodo = (totalHoras)*(diasEstudo);

alert("O total de horas estudadas foram de " + (totalHoras));
alert("O total de horas estudadas por periodo foram de " + (totalPeriodo));