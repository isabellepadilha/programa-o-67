let numeroEntregas = parseInt(prompt("Informe o número de entregas feitas"));
let tempoEntregas = parseFloat(prompt("Informe o tempo médio por entregas em minutos"));
let consumoEntrega = parseFloat(prompt("Informe o consumo médio de combustível em litros"));
let precoCombustivel = parseFloat(prompt("Informe o preço da gasolina na região"));

let tempoTotal = ((numeroEntregas)*(tempoEntregas))/60;
let consumoTotal = (tempoTotal)*(consumoEntrega);
let custoTotal = (consumoTotal)*(precoCombustivel);
let custoMedio = (custoTotal)/(numeroEntregas);

alert("O tempo total das entregas foi de " + (tempoTotal.toFixed(2)));
alert("O consumo total foi de " + (consumoTotal.toFixed(2)));
alert("O custo total foi de " + (custoTotal.toFixed(2)));
alert("O cuto médio por entrega foi de " + (custoMedio.toFixed(2)));