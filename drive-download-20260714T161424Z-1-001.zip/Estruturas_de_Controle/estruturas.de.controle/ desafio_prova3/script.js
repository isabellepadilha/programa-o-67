//   Entradas //
let areaPintada = parseFloat(prompt("Informe a área total a ser pintada"));
let rendimentoTinta = parseFloat(prompt("Informe a quantidade de tinta que será usada em metros quadrados por litro"));
let volumeLata = parseFloat(prompt("Informe o volume da lata em litros"));
let precoLata = parseFloat(prompt("Informe o preço unitário por lata"));
let horasPintura = parseFloat(prompt("Informe a quantidade de horas estimadas para a execução do serviço"));
let quantidadePintores = parseInt(prompt("Informe a quantidade de pintores alocados na equipe"));
let valorHora = parseFloat(prompt("Informe o valor cobrado por hora pelo pintor"));
let valorReservado = parseFloat(prompt("Informe o orçamento máximo disponível pela família"));

// calculos total //
let litrosUsados = areaPintada / rendimentoTinta;
let latasUsadas = Math.ceil(litrosUsados / volumeLata);
let custoTinta = latasUsadas * precoLata;
let maoObra = (horasPintura * quantidadePintores) * valorHora;

// calculos if else //
 const limite30 =

    // if else //

    let valorTotal= maoObra + custoTinta;

if (valorReservado >= valorTotal) {
    let desconto = valorTotal * 0.95;
    let saldoFinal = valorReservado - desconto;
    alert("Seu pagamento será a vista e você terá um desconto de 5% do valor total, o total a pagar será de " + (saldoFinal));
}


