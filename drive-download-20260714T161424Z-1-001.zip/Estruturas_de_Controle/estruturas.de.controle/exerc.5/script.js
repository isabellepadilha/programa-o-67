let valorA = parseFloat(prompt("Informe o valor de A"));
let valorB = parseFloat(prompt("Informe o valor de B"));
let resultado = " ";
if(valorA > valorB){
    resultado = " É maior!";
} else {
    resultado = " É menor!";
}
alert(resultado);