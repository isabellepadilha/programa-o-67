let saldo = parseFloat(prompt("Informe seu saldo por favor"));

if( saldo < 500){
    alert("Você não ganhará nenhum crédito");
} else if (saldo >= 500 && saldo <= 1000){
    let credito = saldo * 0.30;
    alert("Você receberá um crédito de 30%, seu crédito foi de " + (credito.toFixed(2)));
} else {
    let novoCredito = saldo * 0.50;
    alert("Você receberá um crédito de 50%, seu crédito foi de  " + (novoCredito.toFixed(2)))
}