let numero1 = parseFloat(prompt("Informe o primeiro número escolhido por favor."));
let numero2 = parseFloat(prompt("Informe o segundo nuḿero escolhido"));
let operador = prompt("Informe a operação desejada. Ex: soma,divisão,subtração ou multiplicação");

if (operador == "soma") {
    let resultado = numero1 + numero2;
    alert("O resultado da sua operação foi " + (resultado));
} else if (operador == "subtração") {
    let calculo = numero1 - numero2;
    alert(" O resultado da sua operação foi " + (calculo));
} else if (operador == "divisão") {
    let operação = numero1 / numero2;
    alert("O resultado da sua operação foi " + (operação))
} else {
    let conta = numero1 * numero2;
    alert(" O resultado da sua operação foi " + (conta));
}