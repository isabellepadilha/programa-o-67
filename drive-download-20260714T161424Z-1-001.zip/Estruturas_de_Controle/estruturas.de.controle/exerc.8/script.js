const precoG = 5.65;
const precoE = 4.38;
let tipoCombustivel = prompt("Informe o tipo de combustível que será usado, digite G ou E").toUpperCase();
let capacidadeDoTanque = parseFloat(prompt("Informe a capacidade do tanque em litros"));

if (tipoCombustivel === G) {
    let calculo = precoG * capacidadeDoTanque;
    alert("O total para abastecer seu tanque será de " + (calculo.toFixed(2)));
} else if (tipoCombustivel === E) {
    let resultado = precoE * capacidadeDoTanque;
    alert("O total para abastecer seu tanque será de " + (resultado.toFixed(2)));
} else {
    alert("Inválido, tente novamente!!!");
}