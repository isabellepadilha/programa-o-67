let velocidade = parseFloat(prompt("Informe a velocidade do carro,por favor"));
if(velocidade <= 80){
    alert("Não está acima da velocidade.");
} else {
    alert("Está acima da velocidade.");
}
