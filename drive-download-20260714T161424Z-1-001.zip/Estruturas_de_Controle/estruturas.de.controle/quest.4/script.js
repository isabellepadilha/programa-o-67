let lado1 = parseFloat(prompt("Informe o valor do primeiro lado do triângulo"));
let lado2 = parseFloat(prompt("Informe o valor do segundo lado do triângulo"));
let lado3 = parseFloat(prompt("Informe o valor do terceiro lado do triângulo"));

if( lado1 == lado2 && lado3){
    alert("Esse triângulo é equilátero");
} else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3){
    alert("Esse triangulo é isósceles");
} else {
    alert("Esse triângulo é escaleno");
}
