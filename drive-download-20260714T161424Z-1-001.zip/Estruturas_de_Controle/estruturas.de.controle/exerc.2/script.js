const nome = "Esther";
if(nome === "Esther"){
    console.log("Olá Esther seja bem-vinda!");
}
