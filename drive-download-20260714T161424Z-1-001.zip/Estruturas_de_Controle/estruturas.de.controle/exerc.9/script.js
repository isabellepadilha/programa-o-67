let quantDinheiro = parseFloat(prompt("Informe a quantidade de dinheiro presente em seu caixa."));
let quantProdutos = parseInt(prompt("Informe a quantidade de produtos a ser comprada."));
let precoUnidade = parseFloat(prompt("Informe o preço de cada unidade."));
let valorTotal =(quantProdutos*precoUnidade);
let oitentaCaixa = quantDinheiro * 0.80;

if(valorTotal > oitentaCaixa){
    let calculo = (valorTotal + (valorTotal * 0.10))/ 3;
    alert("O total foi de " +  (calculo.toFixed(2)) + " reais.Para pagar a prazo, dividido por 3 parcelas.");
} else {
    let resultado = valorTotal * 0.95;
    alert("O total foi de " + (resultado.toFixed(2)) + " reais.Para pagar o total a vista.");
}
