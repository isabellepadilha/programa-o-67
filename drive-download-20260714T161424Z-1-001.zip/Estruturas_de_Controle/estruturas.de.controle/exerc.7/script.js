let valorInicial = parseInt(prompt("Informe o valor inicial "));
let valorFinal = parseInt(prompt("Informe o valor final"));
let consumo = valorFinal - valorInicial;
let valorKwh = parseFloat(prompt("Infome o valor unitatário do Kwh"));
 if(consumo <= 150){
    fatura = consumo*valorKwh;
 }else{
    let consumoNormal
 }