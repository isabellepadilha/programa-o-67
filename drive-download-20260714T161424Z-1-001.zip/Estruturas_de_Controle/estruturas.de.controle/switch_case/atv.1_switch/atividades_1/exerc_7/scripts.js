let forma = parseInt(prompt("Informe o número da forma, quadrado-1, retângulo-2, círculo-3: "));
let calculo;

switch (forma) {

    case 1:
        let lado = parseFloat(prompt("O lado:"));
        calculo = lado * lado;
        break;

    case 2:
        let base = parseFloat(prompt("Informe a base"));
        let altura = parseFloat(prompt("Informe a altura:"));
        calculo = base * altura;
        break;

    case 3:
        let raio = parseFloat(prompt("Informe o raio:"));
        calculo = Math.PI * (raio ** 2);
        break

    default:
        calculo = "Inválido";

}

alert("Sua área é:" + calculo.toFixed(2));