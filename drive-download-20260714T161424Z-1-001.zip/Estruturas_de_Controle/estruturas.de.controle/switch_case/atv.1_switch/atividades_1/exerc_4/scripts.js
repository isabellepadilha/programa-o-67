let bebida = parseInt(prompt("Informe o código da bebida:"));

switch (bebida) {
    case 1:
        bebida = "Sua bebida é uma águinha geladinha gostosinha.";
        break;

    case 2:
        bebida = "Sua bebida é um refri trincando bem delicinha..";
        break;

    case 3:
        bebida = "Sua bebida é um suquinho que não é fake natty";
        break

    default:
        bebida = "Código de bebida inválido";
        break;
}

alert (bebida);