let saudacao = prompt("Informe uma letra(M, T ou N): ").toUpperCase();

switch (saudaco) {
    case "M":
        saudacao = "Bom dia flor do dia!!!";
        break;

    case "T":
        saudacao = "Boa tarde querido.";
        break;

    case "N":
        saudacao = "Boa noite...";
        break;

    default:
        saudacao = "Digita direito né caramba.";
        break;
}

alert (saudacao);