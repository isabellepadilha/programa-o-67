
let dia = parseInt(prompt("Inofrme um número de 1 a 7:"));

switch (dia) {
    case 1:
        dia = "Domingo!";
        break;

    case 2:
        dia = "Segunda-feira!";
        break;

    case 3:
        dia = "Terça-feira!";
        break;

    case 4:
        dia = "Quarta-feira!";
        break;

    case 5:
        dia = "Quinta-feira!";
        break;

    case 6:
        dia = "Sexta-feira!";
        break;

    case 7:
        dia = "Sábado!";

    default:
        dia = "Inválido."
        break;

}

alert(dia);
