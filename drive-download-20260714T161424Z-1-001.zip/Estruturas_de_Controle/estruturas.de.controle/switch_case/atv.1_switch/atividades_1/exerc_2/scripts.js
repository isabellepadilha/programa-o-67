let numeroUm = parseFloat(prompt("Informe 1 número:"));
let numeroDois = parseFloat(prompt("Informe um segundo número:"));
let operacao = (prompt("Informe uma operação matemática:")).toUpperCase();
let conta;

switch (operacao) {
    case "SOMA":
        conta = numeroUm + numeroDois;
        break;

    case "SUBTRAÇÂO":
        conta = numeroUm - numeroDois;
        break;

    case "MULTIPLICAÇÂO":
        conta = numeroUm * numeroDois;
        break;

    case "DIVISÂO":
        conta = numeroUm / numeroDois;
        break;

    default:
        conta = "Sua operação é inválida.";
        break;
}

alert("Resultado:" + (conta));
