let codigo = parseInt(prompt("Informe o código do produto:"));

switch (codigo) {
    case 100:
        codigo = "Seu produto é um mouse e ele custa R$50,00.";
        break;

    case 200:
        codigo = "Seu produto é um teclado e ele custa R$80,00";
        break;

    case 300:
        codigo = "Seu produto é um monitor e ele custa R$900,00";
        break;

    default:
        codigo = "Código de produto inválido.";

}

alert (codigo);