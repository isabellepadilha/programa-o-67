let codigo = (prompt("Informe o seu código").toUpperCase());
let plano;
let meses = parseFloat(prompt("Informe o número de meses."))
let mensalidade;
let valorTotal;

switch (codigo) {
    case "B":
        plano = "Básico";
        mensalidade = 39.90;
        valorTotal = meses * 39.90;
        break;
    case "P":
        plano = "Profissional";
        mensalidade = 69.90;
        valorTotal = meses * 69.90;
        break;
    case "E":
        plano = "Empresarial";
        mensalidade = 119.90;
        valorTotal = meses * 119.90;
        break;
    default:
        alert("VALOR INVÁLIDO!!!");
        break;
}
alert(" Seu plano é " + (plano) + "\n Sua mensalidade é " + (mensalidade) + "\n O valor total é " + (valorTotal));