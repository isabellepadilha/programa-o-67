let tipoCliente = prompt("Informe o tipo de cliente").toUpperCase();
let valorCompra;
let desconto;

switch(tipoCliente){
    case "A":
        valorCompra = parseFloat(prompt("Informe o valor da compra"));
        desconto = valorCompra * 0.95;
        alert("")
}
