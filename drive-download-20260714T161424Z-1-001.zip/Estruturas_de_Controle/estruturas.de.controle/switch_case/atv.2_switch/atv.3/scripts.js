let conversao = parseInt(prompt("Informe a opção de conversão (digite 1 ou 2)"));
let calculo;
let numero;

switch(conversao){
    case 1:
        numero = parseFloat(prompt("Informe as medidas, por favor"));
        calculo = numero * 1000;
        alert("Sua conversão foi igual a " + (calculo.toFixed(2)) + " metros");
        break;
    case 2:
        numero = parseFloat(prompt("Informe as medidas, por favor"));
        calculo = numero * 0.001;
        alert("Sua conversão foi igual a " + (calculo.toFixed(2)) + " KM"); 
        break;
    default:
        alert("Número digitado inválido, tente novamente");
}