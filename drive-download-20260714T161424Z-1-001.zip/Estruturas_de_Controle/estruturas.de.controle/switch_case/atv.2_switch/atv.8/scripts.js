let sigla = prompt("Informe a sigla da sua Região.").toUpperCase();
let frete;
let regiao;

switch(sigla){
    case "S":
        frete = 20.00;
        regiao = "Sul";
        break;
    case "N":
        frete = 45.00;
        regiao = "Norte";
        break;
    case "SE":
        frete = 25.00;
        regiao = "Sudeste";
        break;
    case "CO":
        frete = 35.00;
        regiao = "Centro - Oeste";
        break;
    case "NE":
        frete = 40.00;
        regiao = "Nordeste";
        break;
    default:
        alert("Sigla Inválida.");
        break;
}
alert("Sua região: " + (regiao) + " Seu frete: " + (frete));

