let transporte = parseInt(prompt("Digite o código do seu meio de transporte, por favor")).toUpperCase();
let resposta;

switch(transporte){
    case "C":
        resposta = "Carro";
    case "M":
        resposta = "Moto";
    case "B":
        resposta = "Bicicleta";
    default:
        resposta = "Código inválido";
}
alert(resposta);