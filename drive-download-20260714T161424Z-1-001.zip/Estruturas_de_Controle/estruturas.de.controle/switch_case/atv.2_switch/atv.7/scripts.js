let codigo = parseInt(prompt("Informe a operação desejada"));
let saldoInicial = 1000;
let saldo;
let saque;
let deposito;

switch(codigo){
    case 1:
        saldo = saldoInicial;
        break;
    case 2:
        saque = parseFloat(prompt("Informe o valor do saque"));

        if(saque <= saldoInicial){
            saldo = saldoInicial - saque;
        } else {
           saldo = "Saldo insuficiente para realizar o saque."; 
        }
        break;
    case 3:
        deposito = parseFloat(prompt("Informe o valor do depósito."));
        saldo = saldoInicial + deposito;
        break;
    default:
        saldo = "INVÁLIDO!!";
        break;
}
alert("Seu saldo final foi de " + (saldo));
