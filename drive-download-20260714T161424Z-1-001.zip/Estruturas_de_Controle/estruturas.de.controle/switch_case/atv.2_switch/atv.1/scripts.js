let curso = parseInt(prompt("Informe o código do seu curso"));
let resposta;

switch(curso){
    case 1:
        resposta = "Seu curso é Informática";
        break;
    case 2:
        resposta = "Seu curso é Administração";
        break;
    case 3:
        resposta = "Seu curso é Redes de Computadores";
        break;
    default:
        resposta = "Curso inválido";
}
alert(resposta);