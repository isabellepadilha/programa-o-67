let categoria = prompt("Digite a categoria da unidade consumidora").toUpperCase();
let quantEnergia;
let calculo;

switch(categoria){
    case "R":
        quantEnergia = parseFloat(prompt("Informe a quantidade de energia consumida em KWh"));
        calculo = quantEnergia * 0.75;
        alert("O total da sua tarifa Residencial foi de  " + (calculo.toFixed(2)));
    case "C":
        quantEnergia = parseFloat(prompt("Informe a quantidade de energia consumida em KWh"));
        calculo = quantEnergia * 0.92;
        alert("O total da sua tarifa Comercial foi de " + (calculo.toFixed(2)));
    case "I":
        quantEnergia = parseFloat(prompt("Informe a quantidade de energia consumida em KWh"));
        calculo = quantEnergia * 0.68;
        alert("O total da sua tarifa Industrial foi de " + (calculo.toFixed(2)));
    default:
        alert("INVÁLIDO");
}