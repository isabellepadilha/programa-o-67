let temperatura = parseInt(prompt("Informe a temperatura atual"));

if(temperatura <= 16 ){
    alert("Está frio");
} else if (temperatura >= 17 && temperatura <= 28 ){
    alert("Está agradavél");
} else {
    alert("Está quente");
}