let nota = parseFloat(prompt("Informe a sua nota final por favor"));
let frequencia = parseFloat(prompt("Informe a sua frequência por favor"));

if (nota >= 7 && frequencia >= 70){
    alert("APROVADO");
} else {
    alert("REPROVADO");
}