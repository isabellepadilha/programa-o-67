let idade = parseInt(prompt("Informe sua idade por favor"));
let acidentes = parseInt(prompt("Informe os acidentes dos últimos 3 anos."));
let airbagABS = prompt("Possui freios ABS e Airbag? Responda com 'sim' ou 'não' ").toUpperCase();
let taxa;

if(idade < 25 || acidentes > 2){
    taxa = 450;

    if(airbagABS == "NÃO"){
        taxa = 450 + 100;
    }
     alert("Perfil de Risco Alto. Valor mensal de " + (taxa));
} else if(idade >= 25 && ( acidentes == 1 || acidentes == 2) || (idade < 25 && acidentes == 0)){
    taxa = 300;

    if(airbagABS == "SIM" ){
        taxa = 300 - 30;
    }
    alert("Perfil de Risco Moderado. Valor mensal de " + (taxa));
} else {
    taxa = 180;
    alert("Perfil de Risco Baixo (Excelente Condutor). Valor mensal de " + (taxa));
}