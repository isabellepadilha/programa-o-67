let valorBruto = parseFloat(prompt("Informe o valor bruto das compras"));
let fidelidade = prompt("Informe seu nível de fidelidade. Digite: Ouro, Prata, Bronze, Outros.").toUpperCase();
let cupomDesconto = prompt("Seu cupom de desconto é válido? Digite 'sim' ou 'não'").toUpperCase();
let valorFinal;
let frete;

if(fidelidade == "OURO"){
    valorFinal = valorBruto * 0.85;

    if(valorFinal < 150){
        frete = "Grátis"
    } else {
        frete = 10.00;
    }
    alert("O valor a pagar da sua compra foi de " + (valorFinal.toFixed(2)) + " e seu frete é " + (frete.toFixed(2)));
} else if (fidelidade == "PRATA"){
    if( cupomDesconto === "SIM"){
        valorFinal = valorBruto * 0.90;
    } else {
        valorFinal = valorBruto * 0.95;
    }

    if(valorFinal >= 250){
        frete = "Grátis";
    } else {
        frete = 20.00;
    }
    alert("O valor final a pagar pela sua compra foi de ")
}