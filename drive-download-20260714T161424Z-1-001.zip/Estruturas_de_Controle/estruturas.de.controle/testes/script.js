let amor = "true";

if( amor === "true"){
 let numero = 0;
 while (numero < 10){
    alert("Eu te amo");
    numero++
 }
}