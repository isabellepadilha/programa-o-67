let idade = 19;
if (idade == 19) {
    console.log ("Pode entrar");
}

if (idade == 25){
    console.log("A idade é maior que 25");
}

