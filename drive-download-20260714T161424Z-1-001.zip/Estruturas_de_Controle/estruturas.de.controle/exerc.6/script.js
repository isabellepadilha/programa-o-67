let altura = parseFloat(prompt("Digite sua altura, por favor"));
let sexo = prompt("Informe seu gênero, digite F ou M.").toUpperCase();
let pesoIdealM = (72.7 * (altura)) - 58;
let pesoIdealF = (62.1 * (altura)) - 47.7;

if (sexo === "F") {
    alert("Seu peso ideal é igual a " + (pesoIdealF.toFixed(2)));
} else if (sexo === "M") {
    alert("Seu peso ideal é igual a " (pesoIdealM.toFixed(2)));
} else {
    alert("SEU PESO E/OU SEXO É INVÁLIDO");
}
