let idade = parseInt(prompt("Informe sua idade, por favor"));
let CNH = prompt("Você tem CNH, sim ou não?");
if (idade >= 18 && CNH == "não") {
    alert("Você não pode dirigir,pois não tem CNH");
} else if (idade >= 18 && CNH == "sim") {
    alert("Você pode dirigir");
} else {
    alert("Você não pode dirigir, pois não tem idade nem CNH");
}
