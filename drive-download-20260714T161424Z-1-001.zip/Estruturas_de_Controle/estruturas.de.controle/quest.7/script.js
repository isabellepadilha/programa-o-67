let passagem = parseFloat(prompt("Informe o preço da passagem"));
let idade = parseInt(prompt("Informe sua idade"));

if(idade >= 7){
    alert(" O total da sua passagem foi de " + (passagem));
} else {
    let novoValor = passagem / 2;
    alert("O total da sua passagem foi de " + (novoValor.toFixed(2)));
}