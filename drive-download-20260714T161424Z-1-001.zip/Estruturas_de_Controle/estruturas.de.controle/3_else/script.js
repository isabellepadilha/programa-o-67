let nome = 'Pedro';
if(nome == 'João'){
    console.log('Seu nome é João');
} else {
    console.log('Seu nome não é João');
}

let velocidade = 100;
if(velocidade <= 80){
    console.log("Não foi multado");
} else {
    console.log ("Foi multado");
}
