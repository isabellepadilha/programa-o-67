let idade = parseInt(prompt("Informe sua idade"));
if(idade > 18){
    console.log("Pode entrar!");
}
