let senha = parseInt(prompt("Informe sua senha (com números)"));
let usuario = prompt("Informe seu usuário por favor.");
const senhaCorreta = 1234;
const usuarioCorreto = "Esther";

if( senha === senhaCorreta && usuario === usuarioCorreto){
    alert("Seja Bem Vindo(a)!!");
}else {
    alert(" SENHA E/OU USUÁRIO INVÁLIDOS !!!");
}